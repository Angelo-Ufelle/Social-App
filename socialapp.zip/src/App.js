import React from 'react';
import './App.css';

const App = () =>{
  return (
    <React.Fragment>
      <div className="App">
        <h1>Social App</h1>
      </div>
    </React.Fragment>
  );
}

export default App;
